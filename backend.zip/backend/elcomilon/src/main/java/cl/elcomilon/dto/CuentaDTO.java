package cl.elcomilon.dto;
import lombok.Data;
@Data
public class CuentaDTO {
    private Long id;
    private Long usuarioId;
    private Integer saldo;
    private String empresaConvenio;
}
