package cl.elcomilon.dto;

import lombok.Data;
@Data
public class PedidoDetalleDTO {
    private Long platoId;
    private Integer cantidad;
    private Integer subtotal;
    private String platoNombre;
}
